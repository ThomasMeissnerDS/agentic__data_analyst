# agentic__data_analyst
Exerimenting with multi-agentic LLMs for dta analysis
