"""
AI Analyst - A data analysis project using multiple LLMs
"""

__version__ = "0.3.2" 